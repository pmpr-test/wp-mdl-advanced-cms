<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Salary; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Salary\AbstractSalary; class Salary extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = __("\101\144\166\x61\156\x63\x65\x64\x20\103\x4d\123\x20\115\157\x64\165\154\x65", PR__MDL__ADVANCED_CMS); } public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { $oeucsuyqysaciasy = $this->yceacaoomkmkesym($xssuewsokckmigqk); $okycmmskgswewacc = []; switch ($oeucsuyqysaciasy) { case Constants::iwascisiiokuackw: if (!($post = $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->awacsmgimwaqmuga($cawesmkieccckaae, Product::wsuoiieigayeicyc))) { goto qwisiamkmkkwucyo; } $qscaoekmoooeuyqg = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->mguqscccckuywsya($post, true); if (!($aqmwamyiwgeeymqa = $this->rkwqmomqeowwyaam($xssuewsokckmigqk, $qscaoekmoooeuyqg))) { goto sgocecweikecwwgq; } $okycmmskgswewacc[] = $aqmwamyiwgeeymqa; sgocecweikecwwgq: qwisiamkmkkwucyo: goto qeuyekusasqmcqms; } yiceawuuiusakwiq: qeuyekusasqmcqms: return $okycmmskgswewacc; } }
