<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\x65\x74\x74\151\156\147", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\101\144\166\141\x6e\143\145\144\40\x43\115\x53\x20\123\x65\x74\164\151\156\x67", PR__MDL__ADVANCED_CMS)); } }
