<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\123\145\164\x74\x69\x6e\x67", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x41\144\166\141\x6e\143\x65\144\x20\103\x4d\x53\x20\123\145\x74\x74\151\x6e\x67", PR__MDL__ADVANCED_CMS)); } }
