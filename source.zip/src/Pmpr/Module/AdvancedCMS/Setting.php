<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\123\x65\x74\164\151\156\147", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x41\144\166\x61\156\x63\145\144\x20\103\x4d\123\40\123\x65\164\x74\151\x6e\147", PR__MDL__ADVANCED_CMS)); } }
