<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function wyyuauosmqoeucmg() { $this->title = __("\x53\145\164\164\x69\x6e\x67", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\x41\144\166\x61\x6e\143\145\x64\40\103\115\123\40\123\145\x74\164\x69\x6e\147", PR__MDL__ADVANCED_CMS)); } }
