<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d169a70242             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\x63\x65\137\x65\x78\164\x65\x72\156\x61\154\x5f\160\154\165\147\151\x6e\x73", [$this, "\157\141\x61\145\141\157\x75\155\171\147\x6d\x67\143\x65\x61\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\163\150\157\x72\x74\x63\x6f\144\145"] = $this->miocmcoykayoyyau()->get("\x74\151\x6e\171\x6d\143\x65\55\160\x6c\165\x67\151\156\x2e\152\163"); } return $mseykiqqcmyesccu; } }
