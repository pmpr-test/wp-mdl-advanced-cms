<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\143\145\x5f\145\x78\x74\x65\x72\156\x61\154\x5f\x70\x6c\x75\147\151\x6e\x73", [$this, "\157\x61\x61\145\141\x6f\165\155\x79\147\x6d\x67\143\145\x61\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\x73\150\x6f\x72\x74\143\x6f\144\145"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\x74\151\156\171\155\x63\145\x2d\x70\154\x75\147\x69\x6e\56\x6a\163"); } return $mseykiqqcmyesccu; } }
