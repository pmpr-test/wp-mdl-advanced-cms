<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\x65\137\145\170\164\x65\x72\156\x61\154\137\160\154\x75\x67\x69\156\163", [$this, "\157\x61\x61\x65\141\157\165\x6d\x79\147\x6d\x67\143\145\x61\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto syiqkaasoueowwui; } $mseykiqqcmyesccu["\x73\x68\157\x72\164\143\157\144\145"] = $this->miocmcoykayoyyau()->get("\164\151\x6e\x79\x6d\143\x65\55\160\154\165\147\x69\156\x2e\152\x73"); syiqkaasoueowwui: return $mseykiqqcmyesccu; } }
