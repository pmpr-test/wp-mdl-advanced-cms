<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\x63\x65\x5f\145\170\x74\x65\162\x6e\141\x6c\x5f\x70\x6c\165\x67\x69\156\163", [$this, "\x6f\141\141\x65\x61\x6f\165\x6d\171\x67\155\x67\x63\145\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto oyiuemaaykgkqqam; } $mseykiqqcmyesccu["\163\x68\157\162\x74\x63\157\x64\x65"] = $this->miocmcoykayoyyau()->get("\164\151\x6e\171\155\x63\x65\55\x70\x6c\165\x67\x69\x6e\x2e\x6a\163"); oyiuemaaykgkqqam: return $mseykiqqcmyesccu; } }
