<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\143\145\137\x65\x78\x74\x65\162\x6e\141\154\x5f\x70\x6c\x75\147\x69\156\163", [$this, "\x6f\141\141\x65\x61\157\165\x6d\x79\x67\x6d\x67\143\x65\x61\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\163\x68\x6f\x72\x74\143\x6f\x64\145"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\164\151\156\x79\x6d\143\145\55\x70\154\x75\147\x69\156\x2e\x6a\163"); } return $mseykiqqcmyesccu; } }
