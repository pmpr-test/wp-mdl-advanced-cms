<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\x65\x5f\145\x78\x74\145\x72\156\x61\x6c\x5f\160\154\165\x67\x69\x6e\163", [$this, "\x6f\x61\141\x65\141\157\165\x6d\171\147\155\147\143\x65\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\163\x68\x6f\x72\164\x63\157\144\145"] = $this->miocmcoykayoyyau()->get("\x74\x69\x6e\171\x6d\x63\145\55\160\154\165\x67\x69\156\x2e\x6a\x73"); } return $mseykiqqcmyesccu; } }
