<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\x65\x5f\145\170\164\145\x72\x6e\x61\x6c\137\x70\x6c\165\x67\151\156\x73", [$this, "\157\141\141\x65\x61\x6f\165\x6d\171\147\155\147\x63\145\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\x73\150\x6f\x72\164\x63\x6f\x64\145"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\x74\x69\156\171\x6d\x63\145\x2d\160\154\165\147\x69\x6e\x2e\x6a\163"); } return $mseykiqqcmyesccu; } }
