<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\x63\145\137\x65\x78\164\x65\x72\x6e\141\x6c\x5f\160\154\x75\147\151\x6e\163", [$this, "\157\x61\141\145\141\157\x75\x6d\x79\147\155\x67\x63\x65\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\163\x68\x6f\162\x74\143\x6f\144\x65"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\164\151\156\x79\155\x63\x65\x2d\x70\x6c\x75\x67\151\x6e\x2e\x6a\163"); } return $mseykiqqcmyesccu; } }
