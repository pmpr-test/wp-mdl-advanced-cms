<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\145\137\x65\x78\x74\145\x72\156\141\x6c\x5f\160\154\x75\147\x69\x6e\x73", [$this, "\x6f\141\x61\x65\x61\x6f\x75\x6d\x79\147\x6d\147\143\x65\x61\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto syiqkaasoueowwui; } $mseykiqqcmyesccu["\x73\x68\x6f\162\x74\x63\157\144\145"] = $this->miocmcoykayoyyau()->get("\x74\x69\156\x79\x6d\x63\145\x2d\160\x6c\165\x67\151\x6e\x2e\152\x73"); syiqkaasoueowwui: return $mseykiqqcmyesccu; } }
