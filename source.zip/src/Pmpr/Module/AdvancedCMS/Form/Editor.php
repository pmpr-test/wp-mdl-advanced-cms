<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\x63\x65\137\145\x78\x74\145\162\156\141\x6c\137\160\154\x75\x67\x69\x6e\x73", [$this, "\157\x61\x61\145\141\157\165\155\171\x67\155\x67\143\145\x61\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\163\x68\x6f\x72\x74\x63\x6f\x64\145"] = $this->miocmcoykayoyyau()->get("\164\x69\x6e\171\155\x63\x65\55\160\154\x75\147\x69\156\x2e\152\163"); } return $mseykiqqcmyesccu; } }
