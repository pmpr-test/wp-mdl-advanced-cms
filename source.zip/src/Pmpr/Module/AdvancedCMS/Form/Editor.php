<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\x63\x65\x5f\x65\170\x74\x65\162\x6e\141\154\137\160\x6c\165\147\x69\156\x73", [$this, "\x6f\141\x61\x65\141\x6f\x75\155\171\147\155\147\x63\x65\141\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\x73\x68\157\162\164\x63\157\x64\x65"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\164\151\156\x79\x6d\143\145\x2d\160\154\165\147\151\156\56\152\x73"); } return $mseykiqqcmyesccu; } }
