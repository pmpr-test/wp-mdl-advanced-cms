<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\x63\x65\137\x65\x78\x74\145\162\x6e\x61\154\x5f\x70\x6c\165\x67\x69\x6e\x73", [$this, "\157\141\x61\145\x61\x6f\x75\155\171\x67\x6d\147\x63\145\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto syiqkaasoueowwui; } $mseykiqqcmyesccu["\163\150\157\x72\164\143\x6f\144\145"] = $this->miocmcoykayoyyau()->get("\x74\151\x6e\171\155\143\145\55\160\x6c\165\147\151\x6e\56\152\x73"); syiqkaasoueowwui: return $mseykiqqcmyesccu; } }
