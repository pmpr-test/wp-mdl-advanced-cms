<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\145\137\x65\x78\164\x65\162\x6e\x61\154\137\160\154\x75\x67\151\x6e\x73", [$this, "\157\x61\x61\x65\141\x6f\165\155\x79\147\155\x67\143\x65\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\x73\150\157\162\164\x63\157\144\x65"] = $this->miocmcoykayoyyau()->get("\164\151\156\171\155\143\145\55\160\154\165\147\151\x6e\x2e\152\163"); } return $mseykiqqcmyesccu; } }
