<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Colorpicker extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\x63\x6f\x6c\x6f\162\160\x69\x63\153\x65\162", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->kesomeowemmyygey("\141\154\160\x68\x61", true)->qigsyyqgewgskemg("\x63\157\154\x6f\162\55\x70\151\x63\153\x65\162")->eskgwaywimqcwcyy("\x63\x6f\154\157\162\160\151\x63\153\145\x72", ''); add_action("\141\x64\x6d\151\x6e\137\146\157\x6f\164\145\162", [$this, "\x65\156\161\165\145\x75\145"], 9999); } public function enqueue() { wp_enqueue_script("\167\160\x2d\143\157\x6c\x6f\x72\x2d\x70\x69\x63\153\145\162"); wp_enqueue_script("\x77\160\55\x63\x6f\x6c\157\162\55\160\x69\143\153\145\162\55\x61\x6c\x70\x68\141"); } }
