<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Colorpicker extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\143\157\x6c\x6f\162\x70\151\143\153\x65\x72", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->kesomeowemmyygey("\141\154\160\150\141", true)->qigsyyqgewgskemg("\143\x6f\x6c\157\162\55\x70\x69\x63\x6b\145\162")->eskgwaywimqcwcyy("\143\x6f\x6c\157\x72\160\151\x63\153\x65\x72", ''); add_action("\x61\144\155\x69\156\x5f\146\157\x6f\x74\x65\x72", [$this, "\x65\156\x71\165\145\165\145"], 9999); } public function enqueue() { wp_enqueue_script("\167\160\x2d\x63\x6f\x6c\157\x72\55\x70\x69\x63\x6b\x65\162"); wp_enqueue_script("\167\160\55\x63\x6f\x6c\157\162\55\x70\x69\x63\x6b\x65\x72\x2d\141\x6c\160\150\x61"); } }
