<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Colorpicker extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\x63\x6f\x6c\x6f\x72\x70\x69\143\153\145\x72", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->kesomeowemmyygey("\x61\x6c\x70\150\x61", true)->qigsyyqgewgskemg("\x63\x6f\154\157\162\55\160\x69\143\153\145\162")->eskgwaywimqcwcyy("\x63\157\154\157\x72\160\x69\x63\153\x65\162", ''); add_action("\141\144\155\x69\156\x5f\146\x6f\x6f\164\x65\162", [$this, "\x65\156\x71\x75\145\x75\x65"], 9999); } public function enqueue() { wp_enqueue_script("\x77\160\x2d\143\157\154\157\162\x2d\160\151\x63\x6b\x65\162"); wp_enqueue_script("\167\x70\x2d\143\157\x6c\x6f\x72\55\160\x69\x63\x6b\145\x72\55\141\154\160\150\x61"); } }
