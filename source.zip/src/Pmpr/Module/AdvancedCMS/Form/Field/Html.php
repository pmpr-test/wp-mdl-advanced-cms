<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Html extends Field { protected $content = null; public function __construct(?string $aokagokqyuysuksm) { parent::__construct("\150\164\x6d\x6c", $aokagokqyuysuksm); } public function souwykwwmyygqyqi() { return $this->content; } public function oguessuismosauuu($ewgwqamkygiqaawc) : self { $this->content = $ewgwqamkygiqaawc; return $this; } }
