<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Hidden extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $eqgoocgaqwqcimie = null) { $this->value = $eqgoocgaqwqcimie; parent::__construct("\x68\151\x64\x64\145\156", $aokagokqyuysuksm); } }
