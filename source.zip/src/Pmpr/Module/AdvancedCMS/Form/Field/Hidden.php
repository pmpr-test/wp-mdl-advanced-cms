<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Hidden extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $eqgoocgaqwqcimie = null) { $this->value = $eqgoocgaqwqcimie; parent::__construct("\150\151\144\x64\145\156", $aokagokqyuysuksm); } }
