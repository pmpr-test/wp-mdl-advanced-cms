<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Hidden extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $eqgoocgaqwqcimie = null) { $this->value = $eqgoocgaqwqcimie; parent::__construct("\x68\x69\144\144\145\x6e", $aokagokqyuysuksm); } }
