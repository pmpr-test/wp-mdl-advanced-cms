<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Hidden extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $eqgoocgaqwqcimie = null) { $this->value = $eqgoocgaqwqcimie; parent::__construct("\150\151\x64\x64\x65\x6e", $aokagokqyuysuksm); } }
