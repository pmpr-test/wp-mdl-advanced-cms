<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Hidden extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $eqgoocgaqwqcimie = null) { $this->value = $eqgoocgaqwqcimie; parent::__construct("\x68\x69\x64\x64\x65\x6e", $aokagokqyuysuksm); } }
