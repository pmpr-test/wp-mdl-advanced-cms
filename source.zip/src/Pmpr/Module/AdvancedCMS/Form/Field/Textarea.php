<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\x6e\151\164\151\x7a\145\x5f\164\x65\x78\164\141\162\145\x61\x5f\146\x69\145\x6c\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\x78\x74\141\x72\145\141"); $this->qigsyyqgewgskemg("\143\x6d\142\x32\x5f\x74\145\x78\x74\141\162\x65\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\x65\170\x74\x61\x72\x65\141\x5f\x63\x6f\144\x65"); $this->sanitizer = [$this, "\x65\x6b\147\157\157\157\151\x67\141\x65\x69\153\x77\145\x6b\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
