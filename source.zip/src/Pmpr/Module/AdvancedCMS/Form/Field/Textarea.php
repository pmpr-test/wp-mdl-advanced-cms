<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\156\151\164\151\172\145\x5f\164\x65\x78\164\x61\x72\145\x61\x5f\146\151\x65\x6c\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\170\164\x61\x72\x65\141"); $this->qigsyyqgewgskemg("\143\x6d\142\x32\x5f\164\x65\170\164\141\x72\x65\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\170\164\141\162\145\141\137\143\157\x64\x65"); $this->sanitizer = [$this, "\145\153\147\157\157\x6f\151\147\141\145\x69\153\x77\x65\x6b\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
