<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\156\x69\164\x69\x7a\145\x5f\164\x65\x78\164\141\162\x65\141\137\x66\x69\145\154\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\145\170\164\x61\x72\x65\141"); $this->qigsyyqgewgskemg("\x63\155\x62\62\137\x74\x65\170\164\x61\x72\145\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\x6f\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\170\164\x61\162\145\x61\x5f\x63\157\x64\x65"); $this->sanitizer = [$this, "\145\x6b\147\x6f\157\157\x69\x67\141\145\x69\153\x77\145\x6b\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
