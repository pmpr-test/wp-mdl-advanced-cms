<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\x61\156\x69\164\151\172\145\x5f\164\145\170\x74\x61\162\x65\x61\x5f\x66\x69\x65\154\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\x78\x74\141\x72\145\x61"); $this->qigsyyqgewgskemg("\143\155\x62\62\137\164\145\x78\x74\141\x72\145\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\x78\164\141\x72\145\x61\x5f\x63\157\144\145"); $this->sanitizer = [$this, "\145\x6b\147\x6f\x6f\x6f\x69\147\141\x65\151\153\167\x65\x6b\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
