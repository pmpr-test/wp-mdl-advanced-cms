<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\141\156\x69\164\151\x7a\145\x5f\164\145\x78\164\141\162\145\x61\x5f\x66\x69\145\154\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\x78\164\141\x72\x65\141"); $this->qigsyyqgewgskemg("\x63\155\x62\62\137\x74\145\x78\x74\x61\162\x65\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\x78\x74\x61\162\145\141\137\x63\x6f\144\145"); $this->sanitizer = [$this, "\x65\153\147\x6f\157\x6f\151\x67\x61\x65\x69\x6b\167\145\153\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
