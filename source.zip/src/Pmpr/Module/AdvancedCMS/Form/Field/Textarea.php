<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\x6e\151\x74\151\172\145\x5f\x74\145\170\x74\141\x72\145\x61\137\x66\x69\x65\154\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\170\164\x61\162\x65\141"); $this->qigsyyqgewgskemg("\143\155\142\x32\x5f\x74\145\170\x74\141\x72\x65\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\x74\x65\170\x74\x61\162\145\x61\137\x63\157\x64\145"); $this->sanitizer = [$this, "\145\153\x67\x6f\157\157\x69\x67\141\145\151\x6b\167\x65\153\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
