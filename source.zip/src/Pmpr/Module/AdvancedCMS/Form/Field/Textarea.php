<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\156\151\x74\151\x7a\x65\137\164\145\x78\164\141\x72\145\141\137\146\151\x65\x6c\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\145\x78\x74\x61\162\145\141"); $this->qigsyyqgewgskemg("\143\155\142\62\x5f\164\145\170\164\141\162\145\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\x78\164\141\162\x65\141\x5f\143\x6f\x64\145"); $this->sanitizer = [$this, "\x65\153\147\x6f\157\157\x69\147\x61\x65\x69\x6b\x77\x65\153\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
