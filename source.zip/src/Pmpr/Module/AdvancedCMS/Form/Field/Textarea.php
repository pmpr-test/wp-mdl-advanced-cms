<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\x61\x6e\151\164\x69\x7a\145\137\164\x65\x78\164\x61\162\x65\x61\137\146\x69\145\x6c\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\145\170\164\x61\x72\x65\x61"); $this->qigsyyqgewgskemg("\143\x6d\x62\x32\137\164\145\170\164\141\x72\x65\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\x74\x65\x78\164\141\x72\145\141\x5f\x63\x6f\144\x65"); $this->sanitizer = [$this, "\x65\153\x67\x6f\157\x6f\151\x67\141\145\x69\x6b\167\x65\x6b\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
