<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\141\x6e\151\x74\151\x7a\145\137\164\145\170\164\x61\x72\x65\x61\137\146\x69\x65\x6c\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\x74\x65\x78\164\141\x72\145\x61"); $this->qigsyyqgewgskemg("\x63\x6d\x62\62\x5f\164\145\x78\x74\x61\x72\x65\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\x6f\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\x74\x65\x78\164\x61\x72\x65\141\x5f\x63\x6f\x64\145"); $this->sanitizer = [$this, "\145\x6b\x67\157\x6f\157\x69\147\141\x65\151\x6b\x77\145\x6b\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
