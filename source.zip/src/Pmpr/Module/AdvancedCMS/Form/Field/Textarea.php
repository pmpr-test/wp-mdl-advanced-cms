<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\x61\x6e\x69\164\151\172\x65\137\x74\145\x78\x74\141\162\x65\x61\137\x66\151\145\x6c\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\x78\164\x61\x72\x65\141"); $this->qigsyyqgewgskemg("\x63\x6d\x62\x32\137\164\145\170\x74\x61\x72\x65\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\x6f\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\170\x74\141\162\145\141\x5f\x63\157\x64\145"); $this->sanitizer = [$this, "\145\x6b\x67\157\157\157\x69\147\141\145\151\x6b\x77\145\x6b\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
