<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\141\x6e\x69\164\x69\x7a\145\x5f\164\145\170\164\x61\x72\145\x61\137\x66\151\145\x6c\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\x74\145\170\x74\141\162\145\x61"); $this->qigsyyqgewgskemg("\143\x6d\x62\x32\137\x74\x65\170\164\141\162\x65\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\x6f\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\x74\x65\x78\164\x61\x72\x65\x61\x5f\x63\157\144\145"); $this->sanitizer = [$this, "\x65\153\147\x6f\157\157\151\147\141\145\151\x6b\167\x65\153\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
