<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Depended extends Checkbox { protected array $targets = []; public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, array $cwucaoaqgwqcwews = [], ?string $mkqqqewsokcswckc = null) { parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->yekmmasckowaowgc($cwucaoaqgwqcwews); $this->usoqcyyugsuyiewc("\144\x65\x70\x65\x6e\144\x65\144"); } public function qammgescyicuwouu() : ?array { return $this->targets; } public function yekmmasckowaowgc($cwucaoaqgwqcwews) : self { $this->targets = $cwucaoaqgwqcwews; return $this; } }
