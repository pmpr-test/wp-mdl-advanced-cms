<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Depended extends Checkbox { protected array $targets = []; public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, array $cwucaoaqgwqcwews = [], ?string $mkqqqewsokcswckc = null) { parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->yekmmasckowaowgc($cwucaoaqgwqcwews); $this->usoqcyyugsuyiewc("\x64\x65\160\145\156\144\x65\144"); } public function qammgescyicuwouu() : ?array { return $this->targets; } public function yekmmasckowaowgc($cwucaoaqgwqcwews) : self { $this->targets = $cwucaoaqgwqcwews; return $this; } }
