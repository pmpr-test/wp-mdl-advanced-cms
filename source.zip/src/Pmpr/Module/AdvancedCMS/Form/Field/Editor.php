<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\x79\x73\x69\x77\x79\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\x32\137\x74\x65\x78\164\141\x72\145\x61\x20\143\155\142\x32\55\x77\171\163\151\167\x79\x67\55\x70\154\141\x63\x65\150\157\154\144\145\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\x65\170\x74\141\162\145\141\137\162\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\x65\144\x69\x61\x5f\142\165\x74\x74\157\x6e\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\144\151\164\x6f\162\137\143\x6c\x61\163\163", $this->waecsyqmwascmqoa("\x63\154\141\x73\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
