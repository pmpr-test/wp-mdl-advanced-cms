<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\171\x73\x69\x77\171\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\62\137\164\145\170\x74\x61\162\145\141\40\x63\x6d\x62\x32\x2d\167\171\163\x69\x77\x79\x67\55\x70\x6c\141\x63\145\x68\157\x6c\144\145\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\145\x78\164\x61\x72\x65\x61\137\162\x6f\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\x65\144\151\141\137\142\x75\164\164\x6f\x6e\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\144\x69\164\x6f\162\x5f\x63\154\x61\163\x73", $this->waecsyqmwascmqoa("\143\x6c\x61\163\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
