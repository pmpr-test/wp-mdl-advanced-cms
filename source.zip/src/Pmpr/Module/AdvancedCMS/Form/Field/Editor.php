<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\x79\x73\x69\167\x79\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\62\137\164\x65\170\x74\141\x72\x65\141\40\x63\155\142\x32\x2d\x77\x79\163\x69\167\171\147\x2d\x70\x6c\x61\143\145\x68\157\x6c\144\x65\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\145\x78\164\x61\162\x65\x61\x5f\162\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\145\x64\x69\141\x5f\x62\x75\164\x74\x6f\156\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\144\151\x74\x6f\x72\x5f\143\154\x61\163\163", $this->waecsyqmwascmqoa("\x63\x6c\x61\163\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
