<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\x79\x73\x69\x77\171\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\142\62\x5f\164\x65\x78\164\141\162\x65\141\x20\143\155\142\62\x2d\167\x79\x73\x69\x77\171\x67\55\x70\154\141\x63\145\150\157\154\x64\145\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\145\170\x74\x61\x72\x65\x61\137\x72\x6f\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\x65\x64\151\x61\137\142\x75\164\164\157\156\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\x64\x69\x74\x6f\162\137\143\154\x61\x73\163", $this->waecsyqmwascmqoa("\143\x6c\141\163\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
