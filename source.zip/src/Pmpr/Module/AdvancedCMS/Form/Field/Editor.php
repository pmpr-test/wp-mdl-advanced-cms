<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\171\x73\x69\167\171\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\x6d\142\x32\137\x74\145\x78\164\x61\x72\x65\141\40\143\155\142\x32\x2d\x77\171\163\151\167\171\147\x2d\160\154\x61\x63\x65\150\157\154\x64\x65\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\x65\170\x74\141\x72\x65\x61\x5f\x72\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\145\x64\x69\141\x5f\142\165\164\164\x6f\156\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\x64\x69\x74\157\x72\137\143\x6c\141\163\x73", $this->waecsyqmwascmqoa("\143\x6c\x61\x73\163")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
