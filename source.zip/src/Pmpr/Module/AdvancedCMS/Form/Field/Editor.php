<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\x79\163\151\x77\x79\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\x6d\142\x32\137\x74\145\x78\164\141\162\145\141\x20\143\x6d\x62\62\x2d\167\x79\163\x69\x77\x79\x67\55\x70\x6c\x61\143\145\x68\x6f\154\144\x65\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\145\170\x74\141\162\145\141\x5f\162\x6f\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\145\144\151\141\x5f\x62\x75\164\x74\x6f\156\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\x64\151\x74\157\x72\137\x63\x6c\141\x73\x73", $this->waecsyqmwascmqoa("\143\154\141\163\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
