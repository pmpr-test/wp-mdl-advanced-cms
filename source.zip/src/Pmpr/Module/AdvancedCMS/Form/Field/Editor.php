<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d169a70242             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\x79\163\x69\x77\x79\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\x63\155\142\x32\137\164\x65\x78\164\x61\162\145\x61\40\x63\155\x62\x32\x2d\x77\x79\x73\x69\x77\x79\x67\x2d\160\x6c\x61\143\145\x68\x6f\154\144\145\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\145\x78\x74\x61\x72\x65\141\x5f\162\x6f\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\145\144\151\141\137\142\x75\164\x74\x6f\x6e\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\144\x69\x74\157\162\x5f\x63\x6c\141\163\163", $this->waecsyqmwascmqoa("\x63\x6c\x61\x73\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
