<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\171\x73\151\167\171\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\142\62\x5f\164\145\170\x74\141\x72\145\x61\x20\x63\155\x62\x32\x2d\167\171\x73\151\x77\171\147\x2d\x70\x6c\141\x63\x65\150\157\154\144\145\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\145\170\x74\141\x72\145\141\x5f\162\157\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\145\x64\151\x61\137\x62\x75\164\164\157\x6e\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\x64\x69\164\x6f\x72\137\143\154\x61\x73\x73", $this->waecsyqmwascmqoa("\143\154\141\163\163")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
