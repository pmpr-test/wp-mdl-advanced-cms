<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\x79\163\x69\167\171\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\142\x32\137\164\145\x78\164\141\162\145\x61\40\143\x6d\x62\62\55\167\x79\x73\x69\167\171\147\x2d\x70\x6c\141\x63\145\x68\x6f\154\x64\145\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\145\x78\x74\x61\x72\145\141\137\x72\157\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\x65\x64\x69\x61\x5f\142\165\x74\164\157\156\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\x64\x69\164\157\x72\x5f\x63\154\141\163\163", $this->waecsyqmwascmqoa("\143\x6c\x61\163\163")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
