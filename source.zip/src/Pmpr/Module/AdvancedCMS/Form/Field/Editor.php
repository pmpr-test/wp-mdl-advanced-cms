<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\x79\163\151\167\171\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\x63\155\x62\62\x5f\x74\x65\x78\x74\141\x72\x65\141\x20\x63\155\x62\x32\55\167\x79\163\151\x77\171\147\x2d\160\x6c\141\x63\145\150\157\154\144\145\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\145\170\164\141\x72\145\x61\x5f\162\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\x65\x64\151\x61\137\142\165\x74\x74\x6f\x6e\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\x64\x69\x74\x6f\162\137\143\x6c\x61\x73\163", $this->waecsyqmwascmqoa("\x63\x6c\141\x73\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
