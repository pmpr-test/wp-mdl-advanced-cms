<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\x79\x73\x69\x77\171\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\x32\x5f\x74\x65\x78\164\141\x72\145\x61\40\143\x6d\x62\62\x2d\x77\x79\163\151\167\x79\x67\55\160\x6c\x61\143\x65\150\x6f\x6c\144\145\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\145\x78\164\x61\162\x65\141\137\x72\x6f\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\145\144\151\x61\x5f\142\x75\164\x74\157\x6e\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\x64\151\164\x6f\x72\x5f\143\154\x61\163\x73", $this->waecsyqmwascmqoa("\x63\x6c\141\163\163")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
