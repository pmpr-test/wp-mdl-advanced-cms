<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Size extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\x73\x69\172\x65", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); } public function eyygsasuqmommkua($qeswwaqqsyymqawg = 50, $cswemwoyesycwkuq = 50) : Field { return parent::eyygsasuqmommkua(["\x77\x69\144\164\150" => $qeswwaqqsyymqawg, "\x68\x65\x69\147\x68\164" => $cswemwoyesycwkuq]); } }
