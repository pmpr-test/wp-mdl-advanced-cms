<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839bedbb08             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Title extends Field { protected ?string $onFront = null; public function __construct(?string $aokagokqyuysuksm, string $ymqmyyeuycgmigyo = null, string $mkqqqewsokcswckc = null) { parent::__construct('title', $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); } public function akimsyoyqymiqaiy() : ?string { return $this->onFront; } public function eywokgocsciueciu($akimsyoyqymiqaiy) : self { $this->onFront = $akimsyoyqymiqaiy; return $this; } }
