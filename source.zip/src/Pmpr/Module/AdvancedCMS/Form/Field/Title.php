<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Title extends Field { protected ?string $onFront = null; public function __construct(?string $aokagokqyuysuksm, string $ymqmyyeuycgmigyo = null, string $mkqqqewsokcswckc = null) { parent::__construct("\x74\x69\x74\x6c\145", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); } public function akimsyoyqymiqaiy() : ?string { return $this->onFront; } public function eywokgocsciueciu($akimsyoyqymiqaiy) : self { $this->onFront = $akimsyoyqymiqaiy; return $this; } }
