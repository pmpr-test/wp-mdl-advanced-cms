<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d169a70242             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\x65\143\164\x6f\162\x2d\x64\x72\157\160\144\x6f\x77\x6e\40\160\162\x2d\x73\x65\x6c\145\143\164\x32"; } }
