<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839bedbb08             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return 'selector-dropdown pr-select2'; } }
