<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6fe69d8d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return 'selector-dropdown pr-select2'; } }
