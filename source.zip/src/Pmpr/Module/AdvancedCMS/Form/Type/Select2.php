<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\x63\x74\157\x72\x2d\144\x72\x6f\x70\x64\x6f\x77\156\x20\x70\x72\x2d\x73\x65\x6c\145\x63\164\x32"; } }
