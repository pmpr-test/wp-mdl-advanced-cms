<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\163\145\x6c\x65\x63\x74\157\162\55\144\x72\157\160\144\x6f\167\156\x20\160\162\55\163\x65\x6c\145\143\x74\62"; } }
