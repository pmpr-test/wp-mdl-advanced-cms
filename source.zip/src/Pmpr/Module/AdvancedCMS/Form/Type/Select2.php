<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\145\154\145\143\x74\157\x72\55\x64\162\x6f\x70\144\x6f\x77\156\x20\160\x72\55\163\145\154\145\143\x74\x32"; } }
