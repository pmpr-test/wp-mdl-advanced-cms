<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\163\145\x6c\145\x63\164\157\162\x2d\144\162\157\160\x64\157\x77\x6e\x20\x70\x72\x2d\163\145\x6c\145\143\x74\x32"; } }
