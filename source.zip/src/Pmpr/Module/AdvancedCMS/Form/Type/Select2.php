<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\163\145\154\145\143\x74\x6f\162\55\144\162\157\x70\144\x6f\167\x6e\40\x70\162\x2d\163\x65\x6c\x65\143\x74\x32"; } }
