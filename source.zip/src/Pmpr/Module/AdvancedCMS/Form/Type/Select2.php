<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\154\145\143\164\x6f\x72\x2d\x64\162\157\160\x64\157\167\x6e\40\x70\162\55\163\145\154\x65\143\x74\x32"; } }
