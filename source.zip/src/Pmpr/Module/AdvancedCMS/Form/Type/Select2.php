<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\145\x6c\145\x63\x74\x6f\162\x2d\x64\x72\157\160\144\157\x77\x6e\40\x70\162\55\x73\x65\x6c\x65\x63\x74\62"; } }
