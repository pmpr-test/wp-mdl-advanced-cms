<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\145\x6c\x65\143\x74\x6f\x72\55\144\x72\x6f\160\144\157\x77\156\x20\160\x72\55\163\x65\x6c\145\x63\164\62"; } }
