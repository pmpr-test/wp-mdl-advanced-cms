<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\143\x74\157\162\x2d\144\162\157\x70\144\157\x77\x6e\40\160\x72\x2d\163\145\x6c\145\143\x74\x32"; } }
