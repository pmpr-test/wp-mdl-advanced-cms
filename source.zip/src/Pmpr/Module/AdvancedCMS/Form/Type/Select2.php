<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\x63\164\157\x72\55\x64\x72\x6f\160\x64\157\x77\156\40\160\162\x2d\163\145\154\145\x63\164\x32"; } }
