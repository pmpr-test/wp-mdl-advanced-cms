<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e27911f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Display extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, 'value', $eqgoocgaqwqcimie); $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), ['class' => $aiowsaccomcoikus->args['classes'], Constants::NAME => $ymygiwwuwyuakysk->_name(), Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs('div', $wwgucssaecqekuek, $eqgoocgaqwqcimie) . $ymygiwwuwyuakysk->_desc(true); } }
