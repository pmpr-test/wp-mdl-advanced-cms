<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Display extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\166\141\154\x75\145", $eqgoocgaqwqcimie); $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), ["\143\x6c\141\163\163" => $aiowsaccomcoikus->args["\143\x6c\141\x73\163\x65\x73"], Constants::NAME => $ymygiwwuwyuakysk->_name(), Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs("\144\151\166", $wwgucssaecqekuek, $eqgoocgaqwqcimie) . $ymygiwwuwyuakysk->_desc(true); } }
