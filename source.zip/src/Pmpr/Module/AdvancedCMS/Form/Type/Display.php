<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Display extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\x76\141\154\x75\145", $eqgoocgaqwqcimie); $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), ["\143\154\x61\x73\163" => $aiowsaccomcoikus->args["\143\x6c\141\x73\163\x65\x73"], Constants::NAME => $ymygiwwuwyuakysk->_name(), Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs("\x64\x69\x76", $wwgucssaecqekuek, $eqgoocgaqwqcimie) . $ymygiwwuwyuakysk->_desc(true); } }
