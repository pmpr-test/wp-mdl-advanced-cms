<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Display extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\x76\141\x6c\165\145", $eqgoocgaqwqcimie); $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), ["\x63\x6c\141\163\163" => $aiowsaccomcoikus->args["\x63\154\x61\163\163\145\163"], Constants::NAME => $ymygiwwuwyuakysk->_name(), Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs("\144\x69\166", $wwgucssaecqekuek, $eqgoocgaqwqcimie) . $ymygiwwuwyuakysk->_desc(true); } }
