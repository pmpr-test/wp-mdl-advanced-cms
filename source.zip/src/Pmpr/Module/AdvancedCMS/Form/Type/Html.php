<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Html extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), [Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $ekiuyucoiagmscgy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\x63\157\156\164\145\x6e\164\137\143\x62"); if ($ekiuyucoiagmscgy) { $aiowsaccomcoikus->args["\x63\157\x6e\164\145\156\164"] = call_user_func_array($aiowsaccomcoikus->args["\143\x6f\156\164\x65\x6e\x74\x5f\143\x62"], [$aiowsaccomcoikus, $kqokimuosyuyyucg, $mqyaskyaekmkegmg]); } $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs("\x64\x69\166", $wwgucssaecqekuek, $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, Constants::ssmskyqgcmeiayco)); } }
