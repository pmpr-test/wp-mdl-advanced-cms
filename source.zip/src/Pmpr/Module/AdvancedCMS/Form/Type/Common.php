<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x63\155\x62\62\137\162\145\156\x64\x65\162\137{$this->gueasuouwqysmomu()}", [$this, "\x72\145\156\x64\x65\162"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x63\x6d\142\62\x5f\x73\x61\156\x69\x74\x69\172\145\137{$this->gueasuouwqysmomu()}", [$this, "\171\x69\151\151\161\145\167\163\163\x65\171\x77\x65\155\161\x75"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return strtolower($this->ugwmakayykcmcmqa()); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
