<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x63\155\142\x32\x5f\x72\x65\x6e\x64\145\x72\x5f{$this->gueasuouwqysmomu()}", [$this, "\x72\145\156\x64\x65\162"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x63\155\x62\62\x5f\x73\x61\x6e\151\x74\x69\172\145\x5f{$this->gueasuouwqysmomu()}", [$this, "\171\151\x69\x69\x71\x65\x77\x73\x73\145\171\167\x65\155\161\165"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return strtolower($this->ugwmakayykcmcmqa()); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
