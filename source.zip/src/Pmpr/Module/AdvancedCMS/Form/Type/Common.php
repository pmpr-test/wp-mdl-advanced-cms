<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x63\155\x62\62\x5f\162\145\x6e\144\145\x72\137{$this->gueasuouwqysmomu()}", [$this, "\x72\145\156\x64\x65\162"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x63\x6d\142\x32\x5f\163\x61\x6e\x69\164\151\x7a\x65\x5f{$this->gueasuouwqysmomu()}", [$this, "\x79\151\151\151\161\145\x77\x73\x73\x65\x79\x77\145\155\x71\x75"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return $this->caokeucsksukesyo()->owgcciayoweymuws()->sggauymmqugqouay($this); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
