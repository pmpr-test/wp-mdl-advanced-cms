<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f89dab2e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("cmb2_render_{$this->gueasuouwqysmomu()}", [$this, 'render'], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("cmb2_sanitize_{$this->gueasuouwqysmomu()}", [$this, 'yiiiqewsseywemqu'], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return $this->caokeucsksukesyo()->owgcciayoweymuws()->sggauymmqugqouay($this); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
