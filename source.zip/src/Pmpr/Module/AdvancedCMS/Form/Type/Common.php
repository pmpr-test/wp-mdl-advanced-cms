<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\143\x6d\142\x32\x5f\162\145\x6e\144\x65\162\137{$this->gueasuouwqysmomu()}", [$this, "\x72\x65\156\144\145\x72"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\143\155\x62\62\x5f\163\141\156\x69\164\151\172\x65\137{$this->gueasuouwqysmomu()}", [$this, "\x79\x69\x69\x69\161\x65\x77\163\163\x65\171\167\145\155\x71\165"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return $this->caokeucsksukesyo()->owgcciayoweymuws()->sggauymmqugqouay($this); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
