<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class MultiButton extends Button { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $qyukicweqoisimwg = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\142\165\164\164\x6f\156\163", []); if (is_array($qyukicweqoisimwg) && $qyukicweqoisimwg) { echo $ymygiwwuwyuakysk->_desc(true); foreach ($qyukicweqoisimwg as $gskauacumcmekigs) { echo $this->generate($gskauacumcmekigs, $ymygiwwuwyuakysk); } } } }
