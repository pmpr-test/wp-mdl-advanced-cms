<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class MultiButton extends Button { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $qyukicweqoisimwg = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\x62\165\164\164\x6f\x6e\x73", []); if (!(is_array($qyukicweqoisimwg) && $qyukicweqoisimwg)) { goto eucqomyqykgoiuge; } echo $ymygiwwuwyuakysk->_desc(true); foreach ($qyukicweqoisimwg as $gskauacumcmekigs) { echo $this->generate($gskauacumcmekigs, $ymygiwwuwyuakysk); qikaewekoecykeou: } yqagomygmeoecwey: eucqomyqykgoiuge: } }
