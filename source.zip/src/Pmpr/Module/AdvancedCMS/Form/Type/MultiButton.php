<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class MultiButton extends Button { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $qyukicweqoisimwg = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\142\x75\164\x74\157\x6e\x73", []); if (!(is_array($qyukicweqoisimwg) && $qyukicweqoisimwg)) { goto kqksuugcgsyeoayy; } echo $ymygiwwuwyuakysk->_desc(true); foreach ($qyukicweqoisimwg as $gskauacumcmekigs) { echo $this->generate($gskauacumcmekigs, $ymygiwwuwyuakysk); ygcsmkuycoagwyou: } omugkkesagcyagmk: kqksuugcgsyeoayy: } }
