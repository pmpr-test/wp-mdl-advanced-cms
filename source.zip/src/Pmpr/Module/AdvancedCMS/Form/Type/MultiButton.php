<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class MultiButton extends Button { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $qyukicweqoisimwg = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\142\165\x74\x74\x6f\x6e\x73", []); if (is_array($qyukicweqoisimwg) && $qyukicweqoisimwg) { echo $ymygiwwuwyuakysk->_desc(true); foreach ($qyukicweqoisimwg as $gskauacumcmekigs) { echo $this->generate($gskauacumcmekigs, $ymygiwwuwyuakysk); } } } }
