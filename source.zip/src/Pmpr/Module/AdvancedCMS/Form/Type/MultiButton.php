<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class MultiButton extends Button { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $qyukicweqoisimwg = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\x62\x75\164\x74\157\x6e\163", []); if (is_array($qyukicweqoisimwg) && $qyukicweqoisimwg) { echo $ymygiwwuwyuakysk->_desc(true); foreach ($qyukicweqoisimwg as $gskauacumcmekigs) { echo $this->generate($gskauacumcmekigs, $ymygiwwuwyuakysk); } } } }
