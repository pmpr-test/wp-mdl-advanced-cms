<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\145\x6c\145\x63\164\x6f\x72\55\x64\162\x6f\160\x64\x6f\167\x6e\40\x70\x72\55\142\x73\x73\x65\x6c\x65\x63\164"; } }
