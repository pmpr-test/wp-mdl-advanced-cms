<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d169a70242             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\143\x74\x6f\162\55\144\162\157\x70\144\157\x77\x6e\x20\x70\x72\55\142\x73\163\145\x6c\145\143\x74"; } }
