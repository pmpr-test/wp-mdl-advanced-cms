<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\145\x6c\x65\x63\164\x6f\x72\x2d\x64\162\x6f\x70\x64\x6f\x77\x6e\40\160\x72\55\142\163\163\x65\154\145\x63\164"; } }
