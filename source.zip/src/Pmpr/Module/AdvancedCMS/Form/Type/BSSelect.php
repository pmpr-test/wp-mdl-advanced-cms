<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\x63\164\x6f\162\55\144\x72\x6f\x70\144\x6f\x77\x6e\40\x70\162\x2d\142\x73\x73\145\x6c\x65\143\x74"; } }
