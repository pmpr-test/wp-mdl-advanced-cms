<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\145\154\145\x63\164\x6f\x72\x2d\x64\x72\157\160\144\157\167\x6e\x20\160\162\55\142\163\x73\145\x6c\x65\x63\x74"; } }
