<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6fe69d8d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return 'selector-dropdown pr-bsselect'; } }
