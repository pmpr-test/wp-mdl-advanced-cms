<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\x65\143\164\x6f\162\55\x64\x72\157\x70\x64\157\x77\x6e\x20\x70\x72\55\142\x73\x73\x65\x6c\x65\x63\164"; } }
