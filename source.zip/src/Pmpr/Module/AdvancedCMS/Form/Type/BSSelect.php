<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\x63\164\157\x72\55\x64\162\x6f\x70\144\x6f\x77\x6e\x20\x70\x72\55\x62\163\x73\x65\x6c\x65\x63\164"; } }
