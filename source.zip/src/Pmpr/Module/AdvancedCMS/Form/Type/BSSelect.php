<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\145\x6c\x65\x63\164\157\162\x2d\144\162\157\x70\x64\157\x77\x6e\x20\160\x72\x2d\x62\x73\163\x65\x6c\x65\x63\164"; } }
