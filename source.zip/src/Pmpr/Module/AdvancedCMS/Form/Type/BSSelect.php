<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\x65\154\x65\143\164\157\162\55\144\162\x6f\x70\144\x6f\167\x6e\x20\x70\162\55\x62\x73\163\145\154\x65\143\164"; } }
