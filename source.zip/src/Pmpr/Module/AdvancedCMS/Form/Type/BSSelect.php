<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\145\x6c\x65\x63\164\x6f\162\55\x64\x72\x6f\x70\144\x6f\167\x6e\x20\x70\x72\x2d\142\x73\163\x65\154\145\x63\164"; } }
