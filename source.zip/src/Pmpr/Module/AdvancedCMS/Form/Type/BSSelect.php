<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\x65\154\145\143\164\x6f\162\55\x64\162\157\x70\144\x6f\x77\x6e\x20\x70\162\55\142\163\163\x65\154\x65\x63\x74"; } }
