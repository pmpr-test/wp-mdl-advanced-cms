<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\145\154\145\143\164\x6f\x72\55\x64\x72\157\160\144\x6f\167\156\x20\x70\x72\x2d\x62\163\163\145\154\145\143\x74"; } }
