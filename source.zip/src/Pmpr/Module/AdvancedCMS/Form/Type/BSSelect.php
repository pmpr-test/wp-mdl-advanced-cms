<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\x65\154\145\x63\164\157\162\x2d\144\162\157\160\144\x6f\167\156\40\x70\162\x2d\x62\x73\163\x65\x6c\x65\x63\x74"; } }
