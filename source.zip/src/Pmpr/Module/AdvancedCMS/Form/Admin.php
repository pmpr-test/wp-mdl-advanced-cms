<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->couwksyewgyeooqe()->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = "\57\x6e\x61\162\x6d\x61\146\172\141\x6d\57\x63\155\142\x32\57\x69\156\x69\x74\56\160\150\160"; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\x2f\x76\145\x6e\x64\157\x72\x2f{$mkomwsiykqigmqca}")) { goto skkamseieeusycye; } if (!$iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\x2e\x2e\x2f\x2e\x2e\57{$mkomwsiykqigmqca}")) { goto wiysogeqqwgioyka; } require_once "{$couygeouymagssgw}\57\x2e\x2e\x2f\x2e\56\57{$mkomwsiykqigmqca}"; wiysogeqqwgioyka: goto cgiscsqwwgqqaeqi; skkamseieeusycye: require_once "{$couygeouymagssgw}\x2f\166\145\x6e\144\157\162\x2f{$mkomwsiykqigmqca}"; cgiscsqwwgqqaeqi: } }
