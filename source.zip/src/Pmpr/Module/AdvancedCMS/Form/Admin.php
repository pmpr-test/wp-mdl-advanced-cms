<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a4128579             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->get($this)->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = '/narmafzam/cmb2/init.php'; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}/vendor/{$mkomwsiykqigmqca}")) { require_once "{$couygeouymagssgw}/vendor/{$mkomwsiykqigmqca}"; } else { if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}/../../{$mkomwsiykqigmqca}")) { require_once "{$couygeouymagssgw}/../../{$mkomwsiykqigmqca}"; } } } }
