<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->couwksyewgyeooqe()->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = "\57\x6e\141\x72\155\141\146\172\x61\155\57\143\x6d\142\x32\57\151\156\x69\x74\56\160\150\160"; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\x76\145\156\144\x6f\x72\x2f{$mkomwsiykqigmqca}")) { goto skkamseieeusycye; } if (!$iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\x2f\x2e\x2e\x2f\x2e\x2e\57{$mkomwsiykqigmqca}")) { goto wiysogeqqwgioyka; } require_once "{$couygeouymagssgw}\57\x2e\56\x2f\x2e\x2e\57{$mkomwsiykqigmqca}"; wiysogeqqwgioyka: goto cgiscsqwwgqqaeqi; skkamseieeusycye: require_once "{$couygeouymagssgw}\57\x76\x65\156\144\x6f\162\x2f{$mkomwsiykqigmqca}"; cgiscsqwwgqqaeqi: } }
