<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->get($this)->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = "\x2f\156\x61\162\155\141\146\x7a\141\155\x2f\143\155\x62\62\57\151\156\151\164\x2e\x70\150\x70"; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\x2f\166\x65\x6e\144\157\162\57{$mkomwsiykqigmqca}")) { require_once "{$couygeouymagssgw}\57\x76\x65\156\144\157\162\57{$mkomwsiykqigmqca}"; } else { if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\56\x2e\x2f\x2e\x2e\57{$mkomwsiykqigmqca}")) { require_once "{$couygeouymagssgw}\x2f\x2e\56\57\56\56\57{$mkomwsiykqigmqca}"; } } } }
