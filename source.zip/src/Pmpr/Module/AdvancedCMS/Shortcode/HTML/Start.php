<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\164\x61\x72\164\x20\123\x68\157\162\164\143\x6f\144\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\x73\137\143\x6f\x6e\x74\141\x69\156\x65\x72", __("\x48\141\163\x20\103\157\156\164\141\151\156\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
