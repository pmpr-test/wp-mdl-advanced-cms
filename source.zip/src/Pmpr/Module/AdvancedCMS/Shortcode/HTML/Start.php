<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\164\141\162\164\40\x53\150\157\162\x74\x63\157\x64\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\x61\x73\x5f\143\157\156\x74\x61\x69\156\x65\162", __("\110\141\163\x20\x43\157\156\164\x61\151\156\145\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
