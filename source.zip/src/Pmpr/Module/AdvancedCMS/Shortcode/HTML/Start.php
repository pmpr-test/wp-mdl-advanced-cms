<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\164\141\162\164\40\x53\150\x6f\162\x74\143\157\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\x73\x5f\x63\157\156\x74\x61\x69\156\145\x72", __("\110\141\x73\x20\103\157\x6e\x74\x61\x69\156\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
