<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\164\141\x72\164\x20\x53\150\157\162\x74\x63\x6f\144\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\x61\x73\x5f\x63\x6f\156\164\x61\151\156\145\162", __("\110\x61\x73\x20\x43\157\156\x74\x61\151\156\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
