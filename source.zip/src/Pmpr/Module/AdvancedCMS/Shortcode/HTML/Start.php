<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\x74\141\x72\164\x20\x53\150\x6f\x72\x74\x63\x6f\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\x61\163\x5f\x63\x6f\x6e\x74\x61\x69\156\x65\x72", __("\110\141\163\40\x43\x6f\x6e\164\x61\151\x6e\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
