<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\164\141\162\x74\x20\123\x68\x6f\162\x74\x63\157\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\x73\137\143\157\x6e\164\x61\x69\156\x65\162", __("\110\x61\163\40\103\157\156\x74\x61\151\x6e\145\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
