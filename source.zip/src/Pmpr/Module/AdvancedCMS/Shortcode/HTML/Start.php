<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\164\x61\162\164\40\x53\x68\157\162\164\x63\x6f\144\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\141\x73\x5f\x63\x6f\x6e\x74\x61\151\156\145\x72", __("\x48\141\x73\40\103\x6f\x6e\164\x61\151\156\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
