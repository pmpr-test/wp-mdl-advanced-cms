<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c0c1c614f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __('Start Shortcode', PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww('has_container', __('Has Container', PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
