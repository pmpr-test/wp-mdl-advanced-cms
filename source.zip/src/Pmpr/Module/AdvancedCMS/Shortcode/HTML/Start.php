<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\164\x61\162\164\40\x53\x68\x6f\162\164\143\x6f\144\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\163\x5f\143\x6f\x6e\164\x61\x69\156\145\x72", __("\x48\x61\163\40\x43\x6f\x6e\x74\141\x69\x6e\x65\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
