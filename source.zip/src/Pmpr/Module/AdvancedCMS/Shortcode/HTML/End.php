<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6fe69d8d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class End extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __('End Shortcode', PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::aikamsoikcwsewac(Constants::eqkeooqcsscoggia)->oguessuismosauuu($this->caokeucsksukesyo()->wgqqgewcmcemoewo()->gmqyuaqwgiayskei(sprintf(__('This shortcode used for close %s, no setting available. remember just use %s after %s. for use this shortcode just press %s button', PR__MDL__ADVANCED_CMS), __('Start Shortcode', PR__MDL__ADVANCED_CMS), __('End Shortcode', PR__MDL__ADVANCED_CMS), __('Start Shortcode', PR__MDL__ADVANCED_CMS), __('Insert Shortcode', PR__MDL__ADVANCED_CMS)), ['class' => 'lh-2'])))); } }
