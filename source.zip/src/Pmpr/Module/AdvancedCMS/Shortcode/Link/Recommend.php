<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Recommend extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::sassayqqokogegcw; $this->title = __("\x52\x65\x63\x6f\155\155\145\x6e\144", PR__MDL__ADVANCED_CMS); } }
