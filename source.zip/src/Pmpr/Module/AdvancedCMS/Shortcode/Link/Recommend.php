<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Recommend extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::sassayqqokogegcw; $this->title = __("\x52\145\143\x6f\155\155\x65\156\144", PR__MDL__ADVANCED_CMS); } }
