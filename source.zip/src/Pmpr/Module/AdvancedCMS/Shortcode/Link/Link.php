<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d6cf09f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Link extends Segment { public function __construct() { $this->parent = Constants::wwmgeoymmaiymyym; $this->target = self::aacsuuycgqoywikw; parent::__construct(); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ckuwucygcwsiawms(Constants::ogigqueukwysusii, __("\114\x69\156\153", PR__MDL__ADVANCED_CMS))->smmismmuuccmscya()->oeewiaacscgyamai("\x70\157\163\x74")->ccmwycqioaicegoc(__("\123\x65\x6c\145\143\x74\x20\141\40\160\157\163\164", PR__MDL__ADVANCED_CMS)))->jyumyyugiwwiqomk(100)); } }
