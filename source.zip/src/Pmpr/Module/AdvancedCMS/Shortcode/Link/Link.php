<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Link extends Segment { public function __construct() { $this->parent = Constants::wwmgeoymmaiymyym; $this->target = self::aacsuuycgqoywikw; parent::__construct(); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ckuwucygcwsiawms(Constants::ogigqueukwysusii, __("\114\x69\x6e\153", PR__MDL__ADVANCED_CMS))->smmismmuuccmscya()->oeewiaacscgyamai("\x70\x6f\x73\x74")->ccmwycqioaicegoc(__("\x53\x65\x6c\145\143\164\x20\x61\x20\x70\157\x73\x74", PR__MDL__ADVANCED_CMS)))->jyumyyugiwwiqomk(100)); } }
