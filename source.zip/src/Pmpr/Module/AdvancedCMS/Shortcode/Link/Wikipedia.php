<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\151\153\151\x70\145\144\x69\x61", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __("\114\x69\x6e\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\164\164\x70\163\x3a\x2f\x2f\146\x61\x2e\167\151\x6b\151\160\x65\x64\151\x61\56\x6f\162\147\57\167\x69\153\151\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\124\145\170\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
