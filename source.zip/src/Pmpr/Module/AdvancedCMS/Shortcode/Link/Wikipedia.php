<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\x69\x6b\x69\160\x65\144\151\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __("\114\x69\156\x6b", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\x74\164\x70\163\72\57\x2f\x66\141\56\x77\151\153\151\160\x65\144\x69\141\x2e\157\x72\x67\x2f\x77\151\x6b\x69\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\x54\x65\170\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
