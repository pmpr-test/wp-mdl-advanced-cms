<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\x69\153\151\x70\145\144\151\x61", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __("\x4c\x69\156\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\150\164\x74\160\163\x3a\57\x2f\x66\x61\x2e\167\x69\153\151\160\145\x64\x69\x61\56\x6f\x72\x67\x2f\167\x69\x6b\151\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\x54\145\x78\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
