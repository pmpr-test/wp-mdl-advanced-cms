<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc504d88b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\x57\151\x6b\151\160\145\x64\151\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __("\x4c\151\x6e\x6b", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\150\x74\164\x70\163\x3a\x2f\x2f\x66\x61\x2e\x77\x69\153\x69\160\x65\x64\x69\x61\x2e\x6f\162\147\57\x77\151\153\x69\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\124\145\x78\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
