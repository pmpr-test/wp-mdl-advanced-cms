<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d169a70242             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\151\x6b\151\160\x65\x64\151\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __("\x4c\151\156\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\150\164\x74\x70\x73\72\x2f\x2f\146\x61\56\x77\151\153\151\160\145\x64\x69\x61\56\157\162\147\x2f\x77\x69\x6b\151\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\124\145\x78\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
