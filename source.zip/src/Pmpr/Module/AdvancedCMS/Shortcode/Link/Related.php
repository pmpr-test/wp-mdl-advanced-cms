<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef23b15             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Related extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::csgwgkuuasoawegc; $this->title = __("\x52\x65\154\141\x74\x65\x64", PR__MDL__ADVANCED_CMS); } }
