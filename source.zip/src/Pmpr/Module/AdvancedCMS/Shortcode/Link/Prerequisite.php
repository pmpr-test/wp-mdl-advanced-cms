<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Prerequisite extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::imoykkmkkkaqgouo; $this->title = __("\x50\162\145\162\x65\x71\x75\x69\x73\151\164\x65", PR__MDL__ADVANCED_CMS); } }
