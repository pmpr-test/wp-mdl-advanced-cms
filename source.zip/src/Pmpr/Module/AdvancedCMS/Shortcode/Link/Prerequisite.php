<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Prerequisite extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::imoykkmkkkaqgouo; $this->title = __("\120\x72\145\162\x65\x71\x75\151\x73\x69\164\145", PR__MDL__ADVANCED_CMS); } }
