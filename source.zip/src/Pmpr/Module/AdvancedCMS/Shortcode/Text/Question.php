<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d169a70242             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Question extends Text { const eeiymeksiysiuemu = "\x61\x6e\163\167\x65\162"; const kuygeqomywoykkai = "\161\x75\x65\163\x74\x69\157\x6e"; public function gogaagekwoisaqgu() { $this->icon = IconInterface::ikkaikqgoksomqoq; $this->title = __("\121\x75\x65\163\164\151\x6f\156", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::kuygeqomywoykkai, __("\x51\165\145\163\x74\151\x6f\x6e", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::eeiymeksiysiuemu, __("\101\x6e\x73\x77\145\162", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->jyumyyugiwwiqomk(100)); } }
