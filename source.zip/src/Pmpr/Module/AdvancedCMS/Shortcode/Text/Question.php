<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Question extends Text { const eeiymeksiysiuemu = "\x61\156\163\x77\x65\162"; const kuygeqomywoykkai = "\161\x75\145\x73\164\151\x6f\x6e"; public function gogaagekwoisaqgu() { $this->icon = IconInterface::ikkaikqgoksomqoq; $this->title = __("\x51\x75\145\x73\164\151\157\x6e", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::kuygeqomywoykkai, __("\x51\165\145\163\164\x69\157\x6e", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::eeiymeksiysiuemu, __("\x41\156\x73\x77\x65\x72", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->jyumyyugiwwiqomk(100)); } }
