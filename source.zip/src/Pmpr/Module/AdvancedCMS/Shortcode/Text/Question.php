<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d00078a083             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Question extends Text { const eeiymeksiysiuemu = "\141\x6e\x73\167\x65\x72"; const kuygeqomywoykkai = "\x71\x75\x65\163\x74\151\x6f\156"; public function gogaagekwoisaqgu() { $this->icon = IconInterface::ikkaikqgoksomqoq; $this->title = __("\x51\x75\145\x73\164\151\157\156", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::kuygeqomywoykkai, __("\x51\165\x65\163\x74\x69\157\156", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::eeiymeksiysiuemu, __("\x41\156\x73\167\145\x72", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->jyumyyugiwwiqomk(100)); } }
