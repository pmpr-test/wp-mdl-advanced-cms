<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\123\x74\141\164\x73\40\141\x6e\144\x20\x49\156\x66\x6f\162\155\141\164\x69\x6f\156", PR__MDL__ADVANCED_CMS); } }
