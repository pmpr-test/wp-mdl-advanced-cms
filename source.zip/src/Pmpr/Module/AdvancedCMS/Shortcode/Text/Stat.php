<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8dc76622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\x53\x74\x61\x74\x73\40\x61\156\x64\40\111\156\146\157\x72\155\x61\x74\x69\x6f\156", PR__MDL__ADVANCED_CMS); } }
