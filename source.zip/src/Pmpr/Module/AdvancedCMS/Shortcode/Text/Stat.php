<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\123\x74\x61\164\x73\40\141\x6e\x64\40\111\156\146\x6f\x72\x6d\x61\164\x69\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
