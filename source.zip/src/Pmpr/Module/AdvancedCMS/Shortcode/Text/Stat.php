<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc07269ac0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\x53\x74\x61\164\163\x20\x61\156\x64\x20\111\x6e\x66\x6f\x72\155\x61\x74\151\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
