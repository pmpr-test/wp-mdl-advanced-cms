<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\123\x74\141\164\x73\x20\x61\x6e\144\40\x49\x6e\146\157\x72\155\x61\164\x69\x6f\156", PR__MDL__ADVANCED_CMS); } }
