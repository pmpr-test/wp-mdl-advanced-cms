<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\x53\164\x61\164\x73\40\141\x6e\x64\x20\x49\156\146\x6f\162\155\141\164\151\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
