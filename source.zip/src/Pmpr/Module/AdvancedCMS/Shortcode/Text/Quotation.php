<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Quotation extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::yqaouicemawuocgm; $this->title = __("\x51\x75\x6f\x74\x61\164\x69\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
