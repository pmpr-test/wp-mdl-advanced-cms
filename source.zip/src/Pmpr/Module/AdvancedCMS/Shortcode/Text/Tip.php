<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78481de3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Tip extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::muqqeuwgookecwyg; $this->title = __("\x54\151\160", PR__MDL__ADVANCED_CMS); } }
