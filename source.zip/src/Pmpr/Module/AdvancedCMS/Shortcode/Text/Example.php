<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Example extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::gmwqguqsyyuasomc; $this->title = __("\x45\170\x61\155\x70\154\145", PR__MDL__ADVANCED_CMS); } }
