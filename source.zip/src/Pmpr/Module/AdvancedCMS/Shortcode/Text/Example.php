<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839bedbb08             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Example extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::gmwqguqsyyuasomc; $this->title = __('Example', PR__MDL__ADVANCED_CMS); } }
