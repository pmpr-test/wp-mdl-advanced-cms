<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cb6c16d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Wrong extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ucomcyskmkiqysee; $this->title = __("\127\x72\157\156\x67\x73", PR__MDL__ADVANCED_CMS); } }
