<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\106\x72\145\x65\x20\x42\157\170", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::class === static::class)) { goto sciwggaeogcoesiu; } $wwgucssaecqekuek[Constants::qescuiwgsyuikume] = ''; sciwggaeogcoesiu: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
