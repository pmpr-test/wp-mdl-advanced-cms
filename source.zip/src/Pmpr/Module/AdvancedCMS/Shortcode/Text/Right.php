<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2b5e0d5821             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Right extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ggokgkyiweugsokc; $this->title = __('Rights', PR__MDL__ADVANCED_CMS); } }
