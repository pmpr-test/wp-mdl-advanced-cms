<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4af920840             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Right extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ggokgkyiweugsokc; $this->title = __("\x52\151\147\x68\x74\163", PR__MDL__ADVANCED_CMS); } }
