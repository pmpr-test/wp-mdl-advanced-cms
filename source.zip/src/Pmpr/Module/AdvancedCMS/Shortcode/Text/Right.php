<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051755168f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Right extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ggokgkyiweugsokc; $this->title = __("\122\x69\x67\x68\164\x73", PR__MDL__ADVANCED_CMS); } }
