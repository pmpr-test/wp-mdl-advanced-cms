<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec39eb7fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media\Video; use Pmpr\Module\AdvancedCMS\Media\Video\Aparat\Aparat; class Video extends Common { public function mameiwsayuyquoeq() { Aparat::symcgieuakksimmu(); } }
