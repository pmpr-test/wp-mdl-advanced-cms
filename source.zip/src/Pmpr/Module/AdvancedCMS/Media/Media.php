<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f89dab2e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Container; use Pmpr\Module\AdvancedCMS\Media\Video\Aparat; class Media extends Container { public function mameiwsayuyquoeq() { } }
