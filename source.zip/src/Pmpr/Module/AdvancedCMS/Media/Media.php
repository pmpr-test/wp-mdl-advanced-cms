<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d0160ad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Container; use Pmpr\Module\AdvancedCMS\Media\Video\Aparat; class Media extends Container { public function mameiwsayuyquoeq() { Aparat::symcgieuakksimmu(); } }
