<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2b5e0d5821             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Container; use Pmpr\Module\AdvancedCMS\Media\Video\Aparat; class Media extends Container { public function mameiwsayuyquoeq() { } }
