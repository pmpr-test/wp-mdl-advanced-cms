<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c0c1c614f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Container; use Pmpr\Module\AdvancedCMS\Media\Video\Aparat; class Media extends Container { public function mameiwsayuyquoeq() { } }
