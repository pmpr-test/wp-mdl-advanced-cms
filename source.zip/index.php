<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a4128579             |
    |_______________________________________|
*/
 use Pmpr\Module\AdvancedCMS\AdvancedCMS; AdvancedCMS::symcgieuakksimmu();
